/**
 * Untuk menyelesaikan tugas latihan, Anda tidak diperbolehkan mengubah struktur kode yang sudah ada. Kecuali:
 *    - Untuk melakukan improvisasi kode
 *    - Mengikuti perintah yang ada
 *
 * Cukup tambahkan kode berdasarkan perintah yang sudah ditentukan.
 *
 */

fun main() {

    // TODO 1
    val vehicle = mapOf<String, String>(
        "vehicle" to "Vehicle",
        "type" to "Type: Motorcycle",
        "maxSpeed" to "Maximal Speed: 230Km/s",
        "maxTank" to "Maximal Tank: 10Ltr"
    )

    // TODO 2
    val type = vehicle.getValue("type")
    val maxSpeed = vehicle.getValue("maxSpeed")
    val maxTank = vehicle.getValue("maxTank")

    // TODO 3
    println(vehicle.getValue("vehicle"))
    println(type)
    println(maxSpeed)
    println(maxTank)

}